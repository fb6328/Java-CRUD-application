/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import java.sql.*;

/**
 *
 * @author fbarasa
 */
public class UpdateUser {

    private String userHere,pass;
    ViewUsers goToUserList = new ViewUsers();

    void doUpdate() {
        //Check if username supplied
        if (userHere != null) {
            int numRows;
            try {
                //Instantiate DbConnection class to use the connection
                DbConnection stayconnected = new DbConnection();
                stayconnected.getConnection();
                //Create the statement object for executing queries
                Statement stmt = stayconnected.con.createStatement();
                //Execute the delete statement and assigned number of affected rows to numRows
                numRows = stmt.executeUpdate("UPDATE logins SET password ='" + pass + "'WHERE userName ='"+userHere+"'");
                if (numRows > 0) {
                    System.out.println("Password for"+userHere+" changed successfully");
                } else {
                    System.out.println("Password change failed. Try again");
                    goToUserList.doList();
                }
                //Close the connection
                stayconnected.con.close();
                goToUserList.doList();
            } catch (SQLException e) {
                System.out.println("Error! See below details \n");
                System.out.println(e);
            }
        } else {
            System.out.println("You must provide a username to update user details");
        }
    }

    public void setUserDetails(String user,String pass) {
        this.userHere = user;
        this.pass = pass;
        doUpdate();
    }
}
