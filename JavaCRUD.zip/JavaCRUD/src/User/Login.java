/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package User;

import java.sql.*;
import java.util.*;

/**
 *
 * @author fbarasa
 */
public class Login extends Home {

    void doLogin() {
        //Check if username or password supplied
        if (user != null || pass != null) {

            try {
                //Instantiate DbConnection class to use the connection
                DbConnection stayconnected = new DbConnection();
                stayconnected.getConnection();
                //Create the statement object for executing queries
                Statement stmt = stayconnected.con.createStatement();
                //Execute the statement
                ResultSet rs = stmt.executeQuery("SELECT * FROM logins WHERE userName ='" + user + "' AND password ='" + pass + "'");
                //Handle the results set
                if (rs.next()) {
                    System.out.println("Login successful");
                    beginAfterLogin();
                } else {
                    System.out.println("Incorrect username or password \n");
                    main(null);
                }
                //Close the connection
                stayconnected.con.close();
            } catch (SQLException e) {
                System.out.println("Error! See below details \n");
                System.out.println(e);
            }
        } else {
            System.out.println("Username or password can not be blank");
        }
    }

    public void setUserDetails(String userName, String password) {
        this.user = userName;
        this.pass = password;
        doLogin();
    }

    void beginAfterLogin() {
        //Ask the user what to do
        Scanner sc = new Scanner(System.in);
        System.out.println("Hello " + user + ", do something:");
        System.out.println("Enter 1 to view users.");
        System.out.println("Enter 2 to add a new user.");
        System.out.println("Enter 3 to Logout");
        choice = sc.nextInt();
        sc.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");
        if (choice == 1) {
            System.out.println("...Users List...");
            //Jump to ViewUsers.java
            ViewUsers viewUserObject = new ViewUsers();
            viewUserObject.doList();
        } else if (choice == 2) {
            System.out.println("...Add New User...");
            System.out.println("Enter username: ");
            user = sc.nextLine();
            System.out.println("Enter password: ");
            pass = sc.nextLine();
            //Jump to AddUser.java
            AddUser addUserObject = new AddUser();
            addUserObject.setUserDetails(user, pass);
        } else if (choice == 3) {
            System.out.println("Logged out...");
            //Jump to DeleteUser.java
           main(null);
        } else {
            System.out.println("Invalid choice");
            main(null);
        }
    }
}
